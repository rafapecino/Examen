package org.example;

public class OutputDevice {
    private int[] validPorts;

    public OutputDevice(int[] validPorts) {
        this.validPorts = validPorts;
    }

    public int[] getValidPorts() {
        return validPorts;
    }

    public void setValidPorts(int[] validPorts) {
        this.validPorts = validPorts;
    }

}
