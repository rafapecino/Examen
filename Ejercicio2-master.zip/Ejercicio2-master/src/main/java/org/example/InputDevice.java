package org.example;

public class InputDevice {
    private String connectorType;
    private int[] validPorts;

    public InputDevice(String connectorType, int[] validPorts) {
        this.connectorType = connectorType;
        this.validPorts = validPorts;
    }

    public String getConnectorType() {
        return connectorType;
    }

    public void setConnectorType(String connectorType) {
        this.connectorType = connectorType;
    }

    public int[] getValidPorts() {
        return validPorts;
    }

    public void setValidPorts(int[] validPorts) {
        this.validPorts = validPorts;
    }
}
