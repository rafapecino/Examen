package org.example;

public class DellInputDevice extends InputDevice {
    private String manufacturer;
    private String model;
    private double price;
    private String connectorType;
    private int[] validPorts;

    public DellInputDevice(String connectorType, int[] validPorts) {
        super(connectorType, validPorts);
        this.manufacturer = manufacturer;
        this.model = model;
        this.price = price;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String getConnectorType() {
        return connectorType;
    }

    @Override
    public void setConnectorType(String connectorType) {
        this.connectorType = connectorType;
    }

    @Override
    public int[] getValidPorts() {
        return validPorts;
    }

    @Override
    public void setValidPorts(int[] validPorts) {
        this.validPorts = validPorts;
    }

    // constructor y métodos de acceso
    public DellInputDevice(String connectorType, int[] validPorts, String manufacturer, String model, double price) {
        super(connectorType, validPorts);
        this.manufacturer = manufacturer;
        this.model = model;
        this.price = price;

    }
}
