package org.example;

public interface ComponentFactory {
    public CentralUnit createCentralUnit();
    public InputDevice createInputDevice(String connectorType, int[] validPorts);
    public OutputDevice createOutputDevice(int[] validPorts);
}
