package org.example;

public class CentralUnit {
    private InputDevice inputDevice;
    private OutputDevice outputDevice;

    public CentralUnit(InputDevice inputDevice, OutputDevice outputDevice) {
        this.inputDevice = inputDevice;
        this.outputDevice = outputDevice;
    }

    public void run() {
        System.out.println("Central unit is running");
    }

    public void setInputDevice(InputDevice inputDevice) {
        this.inputDevice = inputDevice;
    }

    public void setOutputDevice(OutputDevice outputDevice) {
        this.outputDevice = outputDevice;
    }
}
