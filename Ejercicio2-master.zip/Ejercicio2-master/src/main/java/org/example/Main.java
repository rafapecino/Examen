package org.example;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        ComponentFactory componentFactory = new DellComponentFactory();
        CentralUnit centralUnit = componentFactory.createCentralUnit();
        InputDevice inputDevice = componentFactory.createInputDevice("USB", new int[]{1, 2, 3});
        OutputDevice outputDevice = componentFactory.createOutputDevice(new int[]{1, 2, 3});
        centralUnit.setInputDevice(inputDevice);
        centralUnit.setOutputDevice(outputDevice);
        centralUnit.run();
        
        }
    }
