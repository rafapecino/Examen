package org.example;

public class DellOutputDevice extends OutputDevice {
    public DellOutputDevice(int[] validPorts) {
        super(validPorts);
    }
}
