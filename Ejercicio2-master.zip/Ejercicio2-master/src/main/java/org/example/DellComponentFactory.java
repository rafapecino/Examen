package org.example;

public class DellComponentFactory implements ComponentFactory{
    public CentralUnit createCentralUnit() {
        return new DellCentralUnit();
    }
    public InputDevice createInputDevice(String connectorType, int[] validPorts) {
        return new DellInputDevice(connectorType, validPorts);
    }
    public OutputDevice createOutputDevice(int[] validPorts) {
        return new DellOutputDevice(validPorts);
    }
}
