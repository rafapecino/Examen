package Base;

public class Base {
    private  String nombre;
    private  int numeroAmbu;
    private  float tiempoMedioAsistencia;

    public Base(String nombre, int numeroAmbu, float tiempoMedioAsistencia) {
        this.nombre = nombre;
        this.numeroAmbu = numeroAmbu;
        this.tiempoMedioAsistencia = tiempoMedioAsistencia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNumeroAmbu() {
        return numeroAmbu;
    }

    public void setNumeroAmbu(int numeroAmbu) {
        this.numeroAmbu = numeroAmbu;
    }

    public float getTiempoMedioAsistencia() {
        return tiempoMedioAsistencia;
    }

    public void setTiempoMedioAsistencia(float tiempoMedioAsistencia) {
        this.tiempoMedioAsistencia = tiempoMedioAsistencia;
    }
}
