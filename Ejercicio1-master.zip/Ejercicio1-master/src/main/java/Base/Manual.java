package Base;

public class Manual {

    private String nombre;
    private int numeroAmbu;
    private float tiempoMedioAsistencia;

    public Manual(String nombre, int numeroAmbu, float tiempoMedioAsistencia) {
        this.nombre = nombre;
        this.numeroAmbu = numeroAmbu;
        this.tiempoMedioAsistencia = tiempoMedioAsistencia;
    }

    public String print() {
        return "Base{" +
                "nombre='" + nombre + '\'' +
                ", numeroAmbu=" + numeroAmbu +
                ", tiempoMedioAsistencia=" + tiempoMedioAsistencia +
                '}';
    }
}
