package Director;

import builders.BaseBuilder;

import java.lang.foreign.VaList;

public class director {
    public void constructSportsCar(BaseBuilder builder) {

    }

    public void constructBase(BaseBuilder builder) {


    }

    public void constructSUV(BaseBuilder builder) {

    }
}

