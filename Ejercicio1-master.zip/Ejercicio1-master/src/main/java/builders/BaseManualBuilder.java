package builders;

import java.util.List;

public class BaseManualBuilder implements BaseBuilderInterface{
    private String nombre;
    private int numAmbulancias;
    private double tiempoMedioAsistencia;

    @Override
    public void buildNombre(String nombre) {
    this.nombre = nombre;
    }

    @Override
    public void buildNumeroAmbu(int numeroAmbu) {
    this.numAmbulancias = numeroAmbu;
    }

    @Override
    public void buildTiempoMedioAsistencia(float tiempoMedioAsistencia) {
    this.tiempoMedioAsistencia = tiempoMedioAsistencia;
    }

    @Override
    public void buildBases(List<Base> bases) {
    this.buildBases(bases);
    }

    @Override
    public Base obtenerBase() {
        return new Base(nombre, numAmbulancias, tiempoMedioAsistencia);
    }
}
