package builders;

import java.util.List;

public class BaseBuilder implements BaseBuilderInterface {
    private String nombre;
    private int numAmbulancias;
    private double tiempoMedioAsistencia;

    public BaseBuilder withNombre(String nombre) {
        this.nombre = nombre;
        return this;
    }

    public BaseBuilder withNumAmbulancias(int numAmbulancias) {
        this.numAmbulancias = numAmbulancias;
        return this;
    }

    public BaseBuilder withTiempoMedioAsistencia(double tiempoMedioAsistencia) {
        this.tiempoMedioAsistencia = tiempoMedioAsistencia;
        return this;
    }

    public Base build() {
        return new Base(nombre, numAmbulancias, tiempoMedioAsistencia);
    }

    @Override
    public void buildNombre(String nombre) {

    }

    @Override
    public void buildNumeroAmbu(int numeroAmbu) {
        this.numAmbulancias = numeroAmbu;
    }

    @Override
    public void buildTiempoMedioAsistencia(float tiempoMedioAsistencia) {
        this.tiempoMedioAsistencia = tiempoMedioAsistencia;
    }

    @Override
    public void buildBases(List<Base> bases) {
        this.buildBases(bases);
    }

    @Override
    public Base obtenerBase() {
        return new Base(nombre, numAmbulancias, tiempoMedioAsistencia);
    }
}
