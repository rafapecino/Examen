package builders;

import java.util.List;

public interface BaseBuilderInterface {
     void buildNombre(String nombre);
     void buildNumeroAmbu(int numeroAmbu);
    void buildTiempoMedioAsistencia(float tiempoMedioAsistencia);
    void buildBases(List<Base> bases);
    Base obtenerBase();

}
