package builders;

public interface UnidadBuilderInterface {

}
