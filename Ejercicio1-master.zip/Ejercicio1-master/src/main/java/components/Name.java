package components;

import Base.Base;

public class Name{
    private String route;

    public Name() {
        this.route = " ";
    }

    public Name(String manualRoute) {
        this.route = manualRoute;
    }

    public String getRoute() {
        return route;
    }
}
